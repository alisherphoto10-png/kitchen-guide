// src/services/api.ts

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'https://kitchen2026.chefplan.ru'

let _initData = ''

export function setInitData(data: string) {
  _initData = data
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `tg ${_initData}`,
      ...options.headers,
    },
  })

  if (!res.ok) {
    const error = await res.json().catch(() => ({ error: 'Ошибка сети' }))
    throw new Error(error.error || `HTTP ${res.status}`)
  }

  return res.json()
}

// ── TTK ─────────────────────────────────────────────────────────

export const ttkApi = {
  search: (q = '', cat = '') =>
    request<any[]>(`/api/ttk?q=${encodeURIComponent(q)}&cat=${encodeURIComponent(cat)}`),

  getById: (id: string) =>
    request<any>(`/api/ttk/${id}`),

  getCategories: () =>
    request<string[]>('/api/ttk/categories'),
}

// ── PLAN ─────────────────────────────────────────────────────────

export const planApi = {
  get: (section: string, date: string) =>
    request<any>(`/api/plan/${encodeURIComponent(section)}/${date}`),

  getTemplates: () =>
    request<any[]>('/api/plan/templates/my'),

  save: (data: { section: string; date: string; items: any[]; note: string }) =>
    request<any>('/api/plan', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
}

// ── CHECKLIST ─────────────────────────────────────────────────────

export const checklistApi = {
  get: (section: string, date: string) =>
    request<any>(`/api/checklist/${encodeURIComponent(section)}/${date}`),

  toggle: (section: string, date: string, index: number) =>
    request<any>('/api/checklist/toggle', {
      method: 'POST',
      body: JSON.stringify({ section, date, index }),
    }),
}

// ── SHIFT ─────────────────────────────────────────────────────────

export const shiftApi = {
  finish: (note: string) =>
    request<any>('/api/shift/finish', {
      method: 'POST',
      body: JSON.stringify({ note }),
    }),
}

// ── PROFILE ─────────────────────────────────────────────────────

export const profileApi = {
  get: () => request<any>('/api/profile'),
}

// ── ADMIN ─────────────────────────────────────────────────────────

export const adminApi = {
  monitor: () => request<any[]>('/api/admin/monitor'),
  users: () => request<any[]>('/api/admin/users'),
  reports: (section?: string) =>
    request<any[]>(`/api/admin/reports${section ? `?section=${encodeURIComponent(section)}` : ''}`),
  broadcast: (text: string, photoUrl?: string) =>
    request<any>('/api/admin/broadcast', {
      method: 'POST',
      body: JSON.stringify({ text, photo_url: photoUrl }),
    }),
  updateSection: (login: string, section: string) =>
    request<any>(`/api/admin/users/${login}/section`, {
      method: 'POST',
      body: JSON.stringify({ section }),
    }),
  deleteUser: (login: string) =>
    request<any>(`/api/admin/users/${login}`, { method: 'DELETE' }),
}
