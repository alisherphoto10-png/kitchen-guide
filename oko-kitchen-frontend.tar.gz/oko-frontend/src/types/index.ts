// src/types/index.ts

export interface User {
  tg_id: string
  name: string
  username: string
  section: string
  role: 'cook' | 'sushef' | 'chef' | 'admin'
  roleRaw: string
  joined: string
}

export interface TtkItem {
  id: string
  name: string
  category: string
  ingredients: string
  cooking: string
  note: string
  status: string
  yield: string
  kbju: string
}

export interface PlanItem {
  name: string
  min: string
  max: string
  done?: boolean
}

export interface Plan {
  section: string
  date: string
  items: PlanItem[]
  note: string
  createdBy: string
}

export interface SectionStatus {
  section: string
  status: 'empty' | 'filled' | 'partial' | 'done'
  plan: Plan | null
}

export type Role = 'cook' | 'sushef' | 'chef' | 'admin'
