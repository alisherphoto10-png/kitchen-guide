// src/components/features/Admin.tsx
'use client'

import { useState } from 'react'
import { useQuery, useMutation } from '@tanstack/react-query'
import { adminApi } from '@/services/api'
import { useTelegram } from '@/hooks/useTelegram'

const SECTIONS = [
  'Холодный цех', 'Горячий цех', 'Кондитерский цех',
  'Мучной цех', 'Пицца цех', 'Гриль цех'
]

const STATUS_CONFIG = {
  empty: { label: 'Не заполнен', color: 'text-accent-red bg-accent-red/10 border-accent-red/20', icon: '✗' },
  filled: { label: 'Заполнен', color: 'text-accent-green bg-accent-green/10 border-accent-green/20', icon: '✓' },
  partial: { label: 'Частично', color: 'text-accent-orange bg-accent-orange/10 border-accent-orange/20', icon: '⚡' },
  done: { label: 'Завершён', color: 'text-accent-green bg-accent-green/10 border-accent-green/20', icon: '✓' },
}

const SECTION_ICONS: Record<string, string> = {
  'Холодный цех': '🥗',
  'Горячий цех': '🍳',
  'Кондитерский цех': '🍰',
  'Мучной цех': '🥐',
  'Пицца цех': '🍕',
  'Гриль цех': '🔥',
}

const ROLE_LABELS: Record<string, string> = {
  cook: 'Повар',
  sushef: 'Су-шеф',
  chef: 'Шеф',
  admin: 'Администратор',
}

type AdminTab = 'monitor' | 'users' | 'broadcast'

export function Admin() {
  const [tab, setTab] = useState<AdminTab>('monitor')
  const [broadcastText, setBroadcastText] = useState('')
  const [selectedUser, setSelectedUser] = useState<any>(null)
  const [selectedSection, setSelectedSection] = useState('')
  const { haptic } = useTelegram()

  const { data: monitor, isLoading: monitorLoading } = useQuery({
    queryKey: ['monitor'],
    queryFn: adminApi.monitor,
    refetchInterval: 30000,
    enabled: tab === 'monitor',
  })

  const { data: users, isLoading: usersLoading } = useQuery({
    queryKey: ['admin-users'],
    queryFn: adminApi.users,
    enabled: tab === 'users',
  })

  const broadcastMutation = useMutation({
    mutationFn: () => adminApi.broadcast(broadcastText),
    onSuccess: (data) => {
      haptic.success()
      setBroadcastText('')
      alert(`Отправлено: ${data.sent}, ошибок: ${data.failed}`)
    },
  })

  const updateSectionMutation = useMutation({
    mutationFn: ({ login, section }: { login: string; section: string }) =>
      adminApi.updateSection(login, section),
    onSuccess: () => {
      haptic.success()
      setSelectedUser(null)
    },
  })

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-5 pb-3 flex-shrink-0">
        <h1 className="font-display text-xl font-bold text-text-primary mb-4">Управление</h1>

        {/* Tabs */}
        <div className="flex gap-2 bg-surface2 p-1 rounded-2xl">
          {[
            { id: 'monitor', label: 'Мониторинг', icon: '📊' },
            { id: 'users', label: 'Сотрудники', icon: '👥' },
            { id: 'broadcast', label: 'Рассылка', icon: '📢' },
          ].map(t => (
            <button
              key={t.id}
              onClick={() => { haptic.select(); setTab(t.id as AdminTab) }}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1 ${
                tab === t.id
                  ? 'bg-surface text-text-primary shadow-sm'
                  : 'text-text-muted'
              }`}
            >
              <span>{t.icon}</span>
              <span className="hidden sm:inline">{t.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-5 pb-24">

        {/* Monitor */}
        {tab === 'monitor' && (
          <div>
            <p className="text-text-muted text-xs mb-3">Статус планов на сегодня</p>
            {monitorLoading ? (
              <div className="grid grid-cols-2 gap-3">
                {[...Array(6)].map((_, i) => <div key={i} className="h-24 rounded-2xl skeleton" />)}
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {(monitor || []).map((item: any) => {
                  const cfg = STATUS_CONFIG[item.status as keyof typeof STATUS_CONFIG] || STATUS_CONFIG.empty
                  return (
                    <div
                      key={item.section}
                      className={`rounded-2xl p-4 border ${cfg.color}`}
                    >
                      <p className="text-2xl mb-2">{SECTION_ICONS[item.section] || '🏪'}</p>
                      <p className="text-xs font-semibold mb-1 text-current opacity-80">{item.section}</p>
                      <p className="text-xs font-bold">{cfg.icon} {cfg.label}</p>
                      {item.plan && (
                        <p className="text-xs opacity-60 mt-1">
                          {item.plan.items?.filter((i: any) => i.done).length || 0}/{item.plan.items?.length || 0} позиций
                        </p>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )}

        {/* Users */}
        {tab === 'users' && (
          <div className="flex flex-col gap-2">
            {usersLoading ? (
              [...Array(5)].map((_, i) => <div key={i} className="h-16 rounded-2xl skeleton" />)
            ) : (
              (users || []).map((u: any) => (
                <button
                  key={u.login}
                  onClick={() => { haptic.light(); setSelectedUser(u) }}
                  className="touch-feedback w-full text-left rounded-2xl bg-surface border border-white/5 p-4 flex items-center gap-3"
                >
                  <div className="w-10 h-10 rounded-full bg-surface2 flex items-center justify-center font-bold text-sm flex-shrink-0">
                    {u.name?.split(' ').map((w: string) => w[0]).join('').slice(0,2).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-text-primary font-semibold text-sm truncate">{u.name}</p>
                    <p className="text-text-muted text-xs mt-0.5">{u.section || 'Цех не назначен'}</p>
                  </div>
                  <span className="text-xs px-2 py-1 rounded-lg bg-surface2 text-text-muted flex-shrink-0">
                    {ROLE_LABELS[u.role] || u.role}
                  </span>
                </button>
              ))
            )}
          </div>
        )}

        {/* Broadcast */}
        {tab === 'broadcast' && (
          <div>
            <p className="text-text-muted text-xs mb-3">Отправить сообщение всем сотрудникам</p>
            <textarea
              placeholder="Текст рассылки..."
              value={broadcastText}
              onChange={(e) => setBroadcastText(e.target.value)}
              className="w-full bg-surface rounded-2xl p-4 text-text-primary text-sm placeholder-text-muted outline-none border border-white/5 mb-3 resize-none h-36 font-sans"
            />
            <button
              onClick={() => {
                if (!broadcastText.trim()) return
                haptic.medium()
                broadcastMutation.mutate()
              }}
              disabled={!broadcastText.trim() || broadcastMutation.isPending}
              className={`touch-feedback w-full h-13 rounded-2xl font-bold text-sm flex items-center justify-center h-12 ${
                broadcastText.trim()
                  ? 'bg-gradient-to-r from-accent-blue to-blue-600 text-white'
                  : 'bg-surface2 text-text-muted'
              }`}
            >
              {broadcastMutation.isPending ? '⏳ Отправляю...' : '📢 Отправить всем'}
            </button>
          </div>
        )}
      </div>

      {/* User modal */}
      {selectedUser && (
        <div
          className="fixed inset-0 z-50 flex items-end"
          style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)' }}
          onClick={(e) => { if (e.target === e.currentTarget) setSelectedUser(null) }}
        >
          <div className="w-full bg-surface rounded-t-3xl p-6">
            <div className="w-10 h-1 bg-surface3 rounded-full mx-auto mb-5" />
            <h3 className="font-display text-lg font-bold text-text-primary mb-1">{selectedUser.name}</h3>
            <p className="text-text-muted text-sm mb-4">{ROLE_LABELS[selectedUser.role]} · {selectedUser.section || 'Нет цеха'}</p>

            <p className="text-text-muted text-xs mb-2 uppercase tracking-widest font-semibold">Сменить цех</p>
            <div className="flex flex-col gap-2 mb-4">
              {SECTIONS.map(sec => (
                <button
                  key={sec}
                  onClick={() => {
                    haptic.select()
                    setSelectedSection(sec)
                  }}
                  className={`touch-feedback w-full py-3 px-4 rounded-xl text-sm font-semibold text-left transition-all ${
                    selectedSection === sec
                      ? 'bg-accent-green/20 text-accent-green border border-accent-green/30'
                      : 'bg-surface2 text-text-secondary border border-transparent'
                  }`}
                >
                  {SECTION_ICONS[sec]} {sec}
                </button>
              ))}
            </div>

            {selectedSection && (
              <button
                onClick={() => updateSectionMutation.mutate({ login: selectedUser.login, section: selectedSection })}
                disabled={updateSectionMutation.isPending}
                className="touch-feedback w-full h-12 rounded-2xl bg-gradient-to-r from-accent-green to-emerald-500 text-black font-bold mb-2"
              >
                {updateSectionMutation.isPending ? '⏳ Сохраняю...' : `Назначить: ${selectedSection}`}
              </button>
            )}

            <button
              onClick={() => setSelectedUser(null)}
              className="touch-feedback w-full h-12 rounded-2xl bg-surface2 text-text-secondary font-semibold"
            >
              Закрыть
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
