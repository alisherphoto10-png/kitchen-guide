// src/components/features/Plan.tsx
'use client'

import { useState, useEffect } from 'react'
import { useQuery, useMutation } from '@tanstack/react-query'
import { planApi } from '@/services/api'
import { useAppStore } from '@/store'
import { useTelegram } from '@/hooks/useTelegram'

function getDateOptions() {
  const today = new Date()
  const day = today.getDay() // 0=Sun, 1=Mon

  const fmt = (d: Date) =>
    `${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}.${d.getFullYear()}`

  const tomorrow = new Date(today)
  tomorrow.setDate(today.getDate() + 1)

  const options = [
    { label: 'Сегодня', value: fmt(today) },
    { label: 'Завтра', value: fmt(tomorrow) },
  ]

  // If Sunday — add Tuesday
  if (day === 0) {
    const tuesday = new Date(today)
    tuesday.setDate(today.getDate() + 2)
    options.push({ label: 'Вторник', value: fmt(tuesday) })
  }

  return options
}

export function Plan() {
  const { user } = useAppStore()
  const { haptic } = useTelegram()
  const section = user?.section || ''
  const dateOptions = getDateOptions()
  const [selectedDate, setSelectedDate] = useState(dateOptions[0].value)
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [note, setNote] = useState('')
  const [showConfirm, setShowConfirm] = useState(false)
  const [sent, setSent] = useState(false)

  const { data: templates, isLoading } = useQuery({
    queryKey: ['templates', section],
    queryFn: planApi.getTemplates,
    enabled: !!section,
  })

  // Load draft from localStorage
  useEffect(() => {
    if (!section) return
    const draft = localStorage.getItem(`plan_draft_${section}`)
    if (draft) {
      try {
        const { selected: s, note: n } = JSON.parse(draft)
        setSelected(new Set(s))
        setNote(n || '')
      } catch {}
    }
  }, [section])

  // Save draft
  useEffect(() => {
    if (!section) return
    localStorage.setItem(`plan_draft_${section}`, JSON.stringify({
      selected: [...selected],
      note,
    }))
  }, [selected, note, section])

  const saveMutation = useMutation({
    mutationFn: () => {
      const items = (templates || [])
        .filter((_: any, i: number) => selected.has(i))
        .map((t: any) => ({ name: t.name, min: t.min, max: t.max, done: false }))
      return planApi.save({ section, date: selectedDate, items, note })
    },
    onSuccess: () => {
      haptic.success()
      setShowConfirm(false)
      setSent(true)
      setSelected(new Set())
      setNote('')
      localStorage.removeItem(`plan_draft_${section}`)
      setTimeout(() => setSent(false), 3000)
    },
  })

  const toggleItem = (i: number) => {
    haptic.select()
    setSelected(prev => {
      const next = new Set(prev)
      if (next.has(i)) next.delete(i)
      else next.add(i)
      return next
    })
  }

  if (!section) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center px-5">
        <span className="text-5xl mb-4">🏪</span>
        <p className="text-text-primary font-semibold">Цех не назначен</p>
        <p className="text-text-muted text-sm mt-1">Обратитесь к администратору</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-5 pb-3 flex-shrink-0">
        <h1 className="font-display text-xl font-bold text-text-primary mb-1">План заготовок</h1>
        <p className="text-text-muted text-sm mb-4">🏪 {section}</p>

        {/* Date selector */}
        <div className="flex gap-2 mb-4">
          {dateOptions.map(opt => (
            <button
              key={opt.value}
              onClick={() => { haptic.select(); setSelectedDate(opt.value) }}
              className={`flex-1 h-10 rounded-xl text-xs font-semibold transition-all ${
                selectedDate === opt.value
                  ? 'bg-accent-green/20 text-accent-green border border-accent-green/30'
                  : 'bg-surface2 text-text-muted border border-transparent'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        {/* Counter */}
        <div className="flex items-center justify-between bg-surface rounded-2xl px-4 py-3 border border-white/5">
          <span className="text-text-muted text-sm">Выбрано позиций</span>
          <span className="font-display text-2xl font-bold text-accent-orange">{selected.size}</span>
        </div>
      </div>

      {/* Items list */}
      <div className="flex-1 overflow-y-auto px-5 pb-36">
        {isLoading ? (
          <div className="flex flex-col gap-3">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-16 rounded-2xl skeleton" />
            ))}
          </div>
        ) : !templates || templates.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <span className="text-5xl mb-4">📋</span>
            <p className="text-text-primary font-semibold">Шаблон пустой</p>
            <p className="text-text-muted text-sm mt-1">Шаблоны для цеха не настроены</p>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {templates.map((item: any, i: number) => {
              const isSelected = selected.has(i)
              return (
                <button
                  key={i}
                  onClick={() => toggleItem(i)}
                  className={`touch-feedback w-full text-left rounded-2xl p-4 flex items-center gap-3 border transition-all ${
                    isSelected
                      ? 'bg-accent-orange/5 border-accent-orange/30'
                      : 'bg-surface border-white/5'
                  }`}
                >
                  <div className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                    isSelected ? 'bg-accent-orange border-accent-orange' : 'border-surface3'
                  }`}>
                    {isSelected && <span className="text-black text-xs font-bold">✓</span>}
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm font-semibold ${isSelected ? 'text-text-primary' : 'text-text-secondary'}`}>
                      {item.name}
                    </p>
                    <p className="text-text-muted text-xs mt-0.5">{item.min}–{item.max}</p>
                  </div>
                </button>
              )
            })}
          </div>
        )}
      </div>

      {/* Send button */}
      <div className="fixed bottom-20 left-0 right-0 px-5 pb-2">
        {sent ? (
          <div className="w-full h-14 rounded-2xl bg-accent-green/20 border border-accent-green/30 flex items-center justify-center gap-2">
            <span className="text-accent-green font-bold">✓ План отправлен!</span>
          </div>
        ) : (
          <button
            onClick={() => {
              if (selected.size === 0) return
              haptic.medium()
              setShowConfirm(true)
            }}
            disabled={selected.size === 0}
            className={`touch-feedback w-full h-14 rounded-2xl font-bold text-base flex items-center justify-center gap-2 transition-all ${
              selected.size > 0
                ? 'bg-gradient-to-r from-accent-orange to-amber-500 text-black shadow-lg'
                : 'bg-surface2 text-text-muted'
            }`}
            style={selected.size > 0 ? { boxShadow: '0 8px 30px rgba(245,158,11,0.3)' } : {}}
          >
            📋 Отправить план
          </button>
        )}
      </div>

      {/* Confirm modal */}
      {showConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-end"
          style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)' }}
          onClick={(e) => { if (e.target === e.currentTarget) setShowConfirm(false) }}
        >
          <div className="w-full bg-surface rounded-t-3xl p-6">
            <div className="w-10 h-1 bg-surface3 rounded-full mx-auto mb-5" />
            <h3 className="font-display text-lg font-bold text-text-primary mb-2">📋 Отправить план?</h3>
            <p className="text-text-muted text-sm mb-1">
              Выбрано: <strong className="text-accent-orange">{selected.size}</strong> позиций
            </p>
            <p className="text-text-muted text-sm mb-4">На: {selectedDate}</p>
            {selected.size < 3 && (
              <div className="bg-accent-orange/10 border border-accent-orange/30 rounded-xl px-3 py-2 mb-4">
                <p className="text-accent-orange text-xs">⚠️ Выбрано мало позиций. Уверены что всё верно?</p>
              </div>
            )}
            <textarea
              placeholder="Заметка (необязательно)..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-surface2 rounded-2xl p-3 text-text-primary text-sm placeholder-text-muted outline-none border border-white/5 mb-4 resize-none h-20 font-sans"
            />
            <button
              onClick={() => saveMutation.mutate()}
              disabled={saveMutation.isPending}
              className="touch-feedback w-full h-12 rounded-2xl bg-gradient-to-r from-accent-orange to-amber-500 text-black font-bold mb-2"
            >
              {saveMutation.isPending ? '⏳ Отправляю...' : 'Отправить план'}
            </button>
            <button
              onClick={() => setShowConfirm(false)}
              className="touch-feedback w-full h-12 rounded-2xl bg-surface2 text-text-secondary font-semibold"
            >
              Отмена
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
