// src/components/features/Profile.tsx
'use client'

import { useAppStore } from '@/store'

const ROLE_LABELS: Record<string, string> = {
  cook: '👨‍🍳 Повар',
  sushef: '🧑‍🍳 Су-шеф',
  chef: '👑 Шеф-повар',
  admin: '⚙️ Главный администратор',
}

const ROLE_COLORS: Record<string, string> = {
  cook: 'text-text-secondary bg-surface2',
  sushef: 'text-accent-orange bg-accent-orange/10',
  chef: 'text-yellow-400 bg-yellow-400/10',
  admin: 'text-accent-green bg-accent-green/10',
}

export function Profile() {
  const { user, setActiveTab } = useAppStore()

  if (!user) return null

  const initials = user.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()

  return (
    <div className="flex flex-col h-full overflow-y-auto pb-24">
      {/* Header */}
      <div className="px-5 pt-5 pb-3">
        <h1 className="font-display text-xl font-bold text-text-primary">Профиль</h1>
      </div>

      {/* Avatar & Info */}
      <div className="px-5 mb-5">
        <div className="flex flex-col items-center py-8 rounded-3xl bg-surface border border-white/5 relative overflow-hidden">
          {/* Glow */}
          <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-accent-green/10 to-transparent" />

          <div
            className="w-20 h-20 rounded-full flex items-center justify-center font-display text-2xl font-bold text-black mb-4 relative z-10"
            style={{ background: 'linear-gradient(135deg, #22C55E, #059669)' }}
          >
            {initials}
          </div>

          <h2 className="font-display text-xl font-bold text-text-primary mb-2 relative z-10">{user.name}</h2>

          <span className={`px-3 py-1.5 rounded-xl text-xs font-bold relative z-10 ${ROLE_COLORS[user.role] || ROLE_COLORS.cook}`}>
            {ROLE_LABELS[user.role] || user.roleRaw}
          </span>
        </div>
      </div>

      {/* Info cards */}
      <div className="px-5 flex flex-col gap-3">
        <div className="rounded-2xl bg-surface border border-white/5 overflow-hidden">
          {[
            { icon: '🏪', label: 'Цех', value: user.section || 'Не назначен' },
            { icon: '🔑', label: 'Логин', value: 'Скрыт' },
            { icon: '📅', label: 'В системе с', value: user.joined || 'Недавно' },
          ].map((row, i, arr) => (
            <div
              key={row.label}
              className={`flex items-center px-4 py-3.5 ${i < arr.length - 1 ? 'border-b border-white/5' : ''}`}
            >
              <span className="text-xl w-8">{row.icon}</span>
              <span className="text-text-muted text-sm flex-1">{row.label}</span>
              <span className="text-text-primary text-sm font-semibold">{row.value}</span>
            </div>
          ))}
        </div>

        {/* Admin panel link */}
        {['admin', 'chef', 'sushef'].includes(user.role) && (
          <button
            onClick={() => setActiveTab('admin')}
            className="touch-feedback w-full rounded-2xl bg-surface border border-white/5 px-4 py-4 flex items-center gap-3"
          >
            <span className="text-xl">⚙️</span>
            <div className="flex-1 text-left">
              <p className="text-text-primary font-semibold text-sm">Панель управления</p>
              <p className="text-text-muted text-xs">Мониторинг, пользователи, рассылка</p>
            </div>
            <span className="text-text-muted text-lg">›</span>
          </button>
        )}

        {/* App info */}
        <div className="rounded-2xl bg-surface border border-white/5 overflow-hidden">
          {[
            { icon: '🍳', label: 'Приложение', value: 'ОКО Кухня' },
            { icon: '🏪', label: 'Ресторан', value: 'ОКО Гастробар' },
            { icon: '🌍', label: 'Часовой пояс', value: 'Asia/Tashkent' },
          ].map((row, i, arr) => (
            <div
              key={row.label}
              className={`flex items-center px-4 py-3.5 ${i < arr.length - 1 ? 'border-b border-white/5' : ''}`}
            >
              <span className="text-xl w-8">{row.icon}</span>
              <span className="text-text-muted text-sm flex-1">{row.label}</span>
              <span className="text-text-secondary text-sm">{row.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
