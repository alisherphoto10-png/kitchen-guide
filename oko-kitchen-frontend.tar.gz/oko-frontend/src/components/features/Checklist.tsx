// src/components/features/Checklist.tsx
'use client'

import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { checklistApi, shiftApi } from '@/services/api'
import { useAppStore } from '@/store'
import { useTelegram } from '@/hooks/useTelegram'

function formatToday() {
  const d = new Date()
  return `${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}.${d.getFullYear()}`
}

export function Checklist() {
  const { user } = useAppStore()
  const { haptic } = useTelegram()
  const queryClient = useQueryClient()
  const [showFinish, setShowFinish] = useState(false)
  const [note, setNote] = useState('')
  const [optimistic, setOptimistic] = useState<Record<number, boolean>>({})

  const today = formatToday()
  const section = user?.section || ''

  const { data: plan, isLoading } = useQuery({
    queryKey: ['checklist', section, today],
    queryFn: () => checklistApi.get(section, today),
    enabled: !!section,
  })

  const toggleMutation = useMutation({
    mutationFn: (index: number) => checklistApi.toggle(section, today, index),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['checklist', section, today] })
    },
  })

  const finishMutation = useMutation({
    mutationFn: () => shiftApi.finish(note),
    onSuccess: () => {
      setShowFinish(false)
      haptic.success()
      queryClient.invalidateQueries({ queryKey: ['checklist'] })
    },
  })

  const handleToggle = (index: number) => {
    haptic.light()
    setOptimistic(prev => ({ ...prev, [index]: !prev[index] }))
    toggleMutation.mutate(index)
  }

  if (!section) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center px-5">
        <span className="text-5xl mb-4">🏪</span>
        <p className="text-text-primary font-semibold">Цех не назначен</p>
        <p className="text-text-muted text-sm mt-1">Обратитесь к администратору</p>
      </div>
    )
  }

  const items = plan?.items || []
  const doneCount = items.filter((item: any, i: number) =>
    optimistic[i] !== undefined ? optimistic[i] : item.done
  ).length
  const total = items.length
  const progress = total > 0 ? (doneCount / total) * 100 : 0

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-5 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between mb-1">
          <h1 className="font-display text-xl font-bold text-text-primary">Чек-лист</h1>
          <span className="text-xs text-text-muted bg-surface2 px-3 py-1 rounded-xl">{today}</span>
        </div>
        <p className="text-text-muted text-sm mb-4">🏪 {section}</p>

        {/* Progress */}
        {!isLoading && total > 0 && (
          <div className="mb-2">
            <div className="flex justify-between items-center mb-2">
              <span className="text-text-muted text-sm">Выполнено</span>
              <span className="font-display font-bold text-accent-green text-sm">
                {doneCount} / {total}
              </span>
            </div>
            <div className="h-2 bg-surface2 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-accent-green to-emerald-400 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto px-5 pb-32">
        {isLoading ? (
          <div className="flex flex-col gap-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 rounded-2xl skeleton" />
            ))}
          </div>
        ) : !plan ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <span className="text-5xl mb-4">📋</span>
            <p className="text-text-primary font-semibold">План не заполнен</p>
            <p className="text-text-muted text-sm mt-1">Перейдите в раздел «План» чтобы заполнить</p>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {items.map((item: any, i: number) => {
              const isDone = optimistic[i] !== undefined ? optimistic[i] : item.done
              return (
                <button
                  key={i}
                  onClick={() => handleToggle(i)}
                  className={`touch-feedback w-full text-left rounded-2xl p-4 flex items-center gap-3 border transition-all ${
                    isDone
                      ? 'bg-accent-green/5 border-accent-green/20'
                      : 'bg-surface border-white/5'
                  }`}
                >
                  <div className={`w-7 h-7 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                    isDone
                      ? 'bg-accent-green border-accent-green'
                      : 'border-surface3'
                  }`}>
                    {isDone && <span className="text-black text-sm font-bold">✓</span>}
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm font-semibold ${isDone ? 'line-through text-text-muted' : 'text-text-primary'}`}>
                      {item.name}
                    </p>
                    <p className="text-text-muted text-xs mt-0.5">{item.min}–{item.max}</p>
                  </div>
                </button>
              )
            })}
          </div>
        )}
      </div>

      {/* Finish button */}
      {plan && (
        <div className="fixed bottom-20 left-0 right-0 px-5 pb-2">
          <button
            onClick={() => { haptic.medium(); setShowFinish(true) }}
            className="touch-feedback w-full h-14 rounded-2xl bg-gradient-to-r from-accent-green to-emerald-500 text-black font-bold text-base flex items-center justify-center gap-2 shadow-lg"
            style={{ boxShadow: '0 8px 30px rgba(34,197,94,0.3)' }}
          >
            🏁 Завершить смену
          </button>
        </div>
      )}

      {/* Finish modal */}
      {showFinish && (
        <div
          className="fixed inset-0 z-50 flex items-end"
          style={{ background: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)' }}
          onClick={(e) => { if (e.target === e.currentTarget) setShowFinish(false) }}
        >
          <div className="w-full bg-surface rounded-t-3xl p-6">
            <div className="w-10 h-1 bg-surface3 rounded-full mx-auto mb-5" />
            <h3 className="font-display text-lg font-bold text-text-primary mb-2">🏁 Завершить смену?</h3>
            <p className="text-text-muted text-sm mb-4">
              Отчёт отправится в группу и администраторам. Выполнено: {doneCount}/{total}
            </p>
            <textarea
              placeholder="Заметка (необязательно)..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-surface2 rounded-2xl p-3 text-text-primary text-sm placeholder-text-muted outline-none border border-white/5 mb-4 resize-none h-20 font-sans"
            />
            <button
              onClick={() => finishMutation.mutate()}
              disabled={finishMutation.isPending}
              className="touch-feedback w-full h-13 rounded-2xl bg-gradient-to-r from-accent-green to-emerald-500 text-black font-bold mb-2 flex items-center justify-center h-12"
            >
              {finishMutation.isPending ? '⏳ Отправляю...' : 'Отправить отчёт'}
            </button>
            <button
              onClick={() => setShowFinish(false)}
              className="touch-feedback w-full h-12 rounded-2xl bg-surface2 text-text-secondary font-semibold"
            >
              Отмена
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
