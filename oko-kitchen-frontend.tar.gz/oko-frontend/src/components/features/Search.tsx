// src/components/features/Search.tsx
'use client'

import { useState, useCallback, useRef } from 'react'
import { useQuery } from '@tanstack/react-query'
import { ttkApi } from '@/services/api'
import { useTelegram } from '@/hooks/useTelegram'
import type { TtkItem } from '@/types'

function debounce<T extends (...args: any[]) => any>(fn: T, delay: number) {
  let timer: NodeJS.Timeout
  return (...args: Parameters<T>) => {
    clearTimeout(timer)
    timer = setTimeout(() => fn(...args), delay)
  }
}

function TtkCard({ ttk, onOpen }: { ttk: TtkItem; onOpen: (ttk: TtkItem) => void }) {
  const isArchive = ttk.status === 'архив'
  return (
    <button
      onClick={() => onOpen(ttk)}
      className="touch-feedback w-full text-left rounded-2xl bg-surface border border-white/5 p-4 flex items-center gap-3"
    >
      <div className="w-10 h-10 rounded-xl bg-surface2 flex items-center justify-center text-lg flex-shrink-0">
        {ttk.category.includes('суп') || ttk.category.includes('Суп') ? '🍲' :
         ttk.category.includes('салат') || ttk.category.includes('Салат') ? '🥗' :
         ttk.category.includes('соус') || ttk.category.includes('Соус') ? '🫙' :
         ttk.category.includes('паст') || ttk.category.includes('Паст') ? '🍝' :
         ttk.category.includes('полуфаб') || ttk.name.startsWith('ПФ') ? '📦' : '🍽'}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-text-primary font-semibold text-sm truncate">{ttk.name}</p>
        <p className="text-text-muted text-xs mt-0.5">{ttk.category}</p>
      </div>
      {isArchive && (
        <span className="text-xs px-2 py-0.5 rounded-lg bg-text-muted/20 text-text-muted flex-shrink-0">
          архив
        </span>
      )}
      <span className="text-text-muted text-lg">›</span>
    </button>
  )
}

function TtkDetail({ ttk, onBack }: { ttk: TtkItem; onBack: () => void }) {
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-4 pb-3 flex items-center gap-3 flex-shrink-0">
        <button
          onClick={onBack}
          className="touch-feedback w-9 h-9 rounded-xl bg-surface2 flex items-center justify-center text-text-secondary"
        >
          ←
        </button>
        <div className="flex-1 min-w-0">
          <h2 className="font-display text-base font-bold text-text-primary truncate">{ttk.name}</h2>
          <p className="text-text-muted text-xs">{ttk.category}</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-24">
        {/* Ingredients */}
        <div className="rounded-2xl bg-surface border border-white/5 overflow-hidden mb-3">
          <div className="px-4 py-2.5 bg-surface2 border-b border-white/5">
            <p className="text-text-muted text-xs font-semibold uppercase tracking-widest">🧾 Ингредиенты</p>
          </div>
          <div className="px-4 py-3">
            <p className="text-text-primary text-sm leading-relaxed">{ttk.ingredients || '—'}</p>
          </div>
        </div>

        {/* Cooking */}
        <div className="rounded-2xl bg-surface border border-white/5 overflow-hidden mb-3">
          <div className="px-4 py-2.5 bg-surface2 border-b border-white/5">
            <p className="text-text-muted text-xs font-semibold uppercase tracking-widest">👨‍🍳 Приготовление</p>
          </div>
          <div className="px-4 py-3">
            <p className="text-text-primary text-sm leading-relaxed">{ttk.cooking || '—'}</p>
          </div>
        </div>

        {/* Note */}
        {ttk.note && (
          <div className="rounded-2xl bg-surface border border-white/5 overflow-hidden mb-3">
            <div className="px-4 py-2.5 bg-surface2 border-b border-white/5">
              <p className="text-text-muted text-xs font-semibold uppercase tracking-widest">📝 Примечание</p>
            </div>
            <div className="px-4 py-3">
              <p className="text-text-primary text-sm leading-relaxed">{ttk.note}</p>
            </div>
          </div>
        )}

        {/* Yield & KBJU */}
        {(ttk.yield || ttk.kbju) && (
          <div className="rounded-2xl bg-surface border border-white/5 overflow-hidden mb-3">
            <div className="px-4 py-2.5 bg-surface2 border-b border-white/5">
              <p className="text-text-muted text-xs font-semibold uppercase tracking-widest">⚖️ Выход и КБЖУ</p>
            </div>
            <div className="px-4 py-3">
              {ttk.yield && <p className="text-text-primary text-sm mb-1">Выход: {ttk.yield}</p>}
              {ttk.kbju && <p className="text-text-secondary text-sm">{ttk.kbju}</p>}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export function Search() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('')
  const [debouncedQuery, setDebouncedQuery] = useState('')
  const [selectedTtk, setSelectedTtk] = useState<TtkItem | null>(null)
  const { haptic } = useTelegram()

  const debouncedSearch = useCallback(
    debounce((q: string) => setDebouncedQuery(q), 400),
    []
  )

  const { data: categories } = useQuery({
    queryKey: ['ttk-categories'],
    queryFn: ttkApi.getCategories,
  })

  const { data: results, isLoading } = useQuery({
    queryKey: ['ttk-search', debouncedQuery, category],
    queryFn: () => ttkApi.search(debouncedQuery, category),
    enabled: true,
  })

  if (selectedTtk) {
    return <TtkDetail ttk={selectedTtk} onBack={() => setSelectedTtk(null)} />
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 pt-5 pb-3 flex-shrink-0">
        <h1 className="font-display text-xl font-bold text-text-primary mb-4">Поиск ТТК</h1>

        {/* Search input */}
        <div className="flex items-center gap-3 bg-surface2 rounded-2xl px-4 h-12 border border-white/5 mb-3">
          <span className="text-text-muted text-lg">🔍</span>
          <input
            type="text"
            placeholder="Поиск по названию..."
            value={query}
            onChange={(e) => {
              setQuery(e.target.value)
              debouncedSearch(e.target.value)
            }}
            className="flex-1 bg-transparent text-text-primary placeholder-text-muted text-sm outline-none font-sans"
          />
          {query && (
            <button
              onClick={() => { setQuery(''); setDebouncedQuery('') }}
              className="text-text-muted text-lg"
            >
              ×
            </button>
          )}
        </div>

        {/* Category chips */}
        {categories && categories.length > 0 && (
          <div className="flex gap-2 overflow-x-auto pb-1 -mx-5 px-5">
            <button
              onClick={() => { haptic.select(); setCategory('') }}
              className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                category === ''
                  ? 'bg-accent-green/20 text-accent-green border border-accent-green/30'
                  : 'bg-surface2 text-text-muted border border-transparent'
              }`}
            >
              Все
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => { haptic.select(); setCategory(cat === category ? '' : cat) }}
                className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  category === cat
                    ? 'bg-accent-green/20 text-accent-green border border-accent-green/30'
                    : 'bg-surface2 text-text-muted border border-transparent'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Results */}
      <div className="flex-1 overflow-y-auto px-5 pb-24">
        {isLoading ? (
          <div className="flex flex-col gap-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-16 rounded-2xl skeleton" />
            ))}
          </div>
        ) : results && results.length > 0 ? (
          <div className="flex flex-col gap-2">
            <p className="text-text-muted text-xs mb-2">Найдено: {results.length}</p>
            {results.map((ttk) => (
              <TtkCard
                key={ttk.id}
                ttk={ttk}
                onOpen={(t) => { haptic.light(); setSelectedTtk(t) }}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <span className="text-5xl mb-4">🔍</span>
            <p className="text-text-primary font-semibold mb-1">Ничего не найдено</p>
            <p className="text-text-muted text-sm">Попробуйте другой запрос</p>
          </div>
        )}
      </div>
    </div>
  )
}
