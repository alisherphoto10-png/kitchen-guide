// src/components/features/Dashboard.tsx
'use client'

import { useAppStore } from '@/store'
import { useTelegram } from '@/hooks/useTelegram'

const ROLE_LABELS: Record<string, string> = {
  cook: 'Повар',
  sushef: 'Су-шеф',
  chef: 'Шеф-повар',
  admin: 'Главный администратор',
}

interface QuickAction {
  id: string
  label: string
  desc: string
  icon: string
  color: string
  glow: string
  tab: string
  roles?: string[]
}

const ACTIONS: QuickAction[] = [
  { id: 'search', label: 'Поиск ТТК', desc: '472 карты', icon: '🔍', color: 'from-blue-500/20 to-blue-600/10', glow: 'rgba(59,130,246,0.15)', tab: 'search' },
  { id: 'checklist', label: 'Чек-лист', desc: 'Смена сегодня', icon: '✅', color: 'from-green-500/20 to-green-600/10', glow: 'rgba(34,197,94,0.15)', tab: 'checklist' },
  { id: 'plan', label: 'План заготовок', desc: 'Заполнить план', icon: '📋', color: 'from-orange-500/20 to-orange-600/10', glow: 'rgba(245,158,11,0.15)', tab: 'plan' },
  { id: 'profile', label: 'Профиль', desc: 'Мои данные', icon: '👤', color: 'from-purple-500/20 to-purple-600/10', glow: 'rgba(168,85,247,0.15)', tab: 'profile' },
  { id: 'admin', label: 'Мониторинг', desc: 'Все цеха', icon: '📊', color: 'from-red-500/20 to-red-600/10', glow: 'rgba(239,68,68,0.15)', tab: 'admin', roles: ['admin', 'chef', 'sushef'] },
]

function formatDate() {
  return new Date().toLocaleDateString('ru-RU', {
    weekday: 'long', day: 'numeric', month: 'long'
  })
}

export function Dashboard() {
  const { user, setActiveTab } = useAppStore()
  const { haptic } = useTelegram()

  const visibleActions = ACTIONS.filter(a =>
    !a.roles || (user && a.roles.includes(user.role))
  )

  return (
    <div className="flex flex-col h-full overflow-y-auto pb-24">
      {/* Header */}
      <div className="relative px-5 pt-6 pb-4">
        {/* Background glow */}
        <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-accent-green/5 to-transparent pointer-events-none" />

        {/* Logo */}
        <div className="flex items-center gap-2 mb-5">
          <div className="w-8 h-8 rounded-xl bg-accent-green/20 flex items-center justify-center">
            <span className="text-sm">🍳</span>
          </div>
          <span className="font-display text-sm font-bold text-accent-green tracking-wider uppercase">
            ОКО Кухня
          </span>
        </div>

        {/* Greeting */}
        <div className="animate-fade-in">
          <p className="text-text-muted text-sm mb-1">{formatDate()}</p>
          <h1 className="font-display text-2xl font-bold text-text-primary leading-tight">
            {user ? `Привет, ${user.name.split(' ')[0]}` : 'Добро пожаловать'}
          </h1>
          {user && (
            <div className="flex items-center gap-2 mt-2">
              <span className="px-2.5 py-1 rounded-lg bg-accent-green/10 text-accent-green text-xs font-semibold">
                {ROLE_LABELS[user.role] || user.roleRaw}
              </span>
              {user.section && (
                <span className="px-2.5 py-1 rounded-lg bg-surface2 text-text-secondary text-xs font-medium">
                  🏪 {user.section}
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Quick actions grid */}
      <div className="px-5">
        <p className="text-text-muted text-xs font-semibold uppercase tracking-widest mb-3">
          Быстрые действия
        </p>
        <div className="grid grid-cols-2 gap-3">
          {visibleActions.map((action, i) => (
            <button
              key={action.id}
              onClick={() => {
                haptic.medium()
                setActiveTab(action.tab as any)
              }}
              className="touch-feedback relative overflow-hidden rounded-2xl p-4 text-left"
              style={{
                background: `linear-gradient(135deg, ${action.color.split(' ')[1].replace('from-', '').replace('/20', '')}20, transparent)`,
                border: '1px solid rgba(255,255,255,0.05)',
                animationDelay: `${i * 60}ms`,
              }}
            >
              <div
                className="absolute inset-0 opacity-0 hover:opacity-100 transition-opacity"
                style={{ background: `radial-gradient(circle at center, ${action.glow}, transparent)` }}
              />
              <span className="text-2xl mb-3 block">{action.icon}</span>
              <p className="text-text-primary font-semibold text-sm leading-tight">{action.label}</p>
              <p className="text-text-muted text-xs mt-0.5">{action.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Status bar */}
      <div className="px-5 mt-5">
        <div className="rounded-2xl bg-surface border border-white/5 p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-text-muted text-xs font-semibold uppercase tracking-widest">Статус системы</p>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-accent-green animate-pulse" />
              <span className="text-accent-green text-xs font-semibold">Активна</span>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'ТТК', value: '472', icon: '📖' },
              { label: 'Цехов', value: '6', icon: '🏪' },
              { label: 'Поваров', value: '10', icon: '👨‍🍳' },
            ].map(stat => (
              <div key={stat.label} className="text-center">
                <p className="text-lg">{stat.icon}</p>
                <p className="font-display text-lg font-bold text-text-primary">{stat.value}</p>
                <p className="text-text-muted text-xs">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
