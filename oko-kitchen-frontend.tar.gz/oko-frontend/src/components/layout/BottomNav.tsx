// src/components/layout/BottomNav.tsx
'use client'

import { useAppStore } from '@/store'
import { useTelegram } from '@/hooks/useTelegram'
import type { User } from '@/types'

const ADMIN_ROLES = ['admin', 'chef', 'sushef']

interface NavItem {
  id: string
  label: string
  icon: string
  roles?: string[]
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Главная', icon: '⚡' },
  { id: 'search', label: 'ТТК', icon: '🔍' },
  { id: 'checklist', label: 'Смена', icon: '✅' },
  { id: 'plan', label: 'План', icon: '📋' },
  { id: 'profile', label: 'Профиль', icon: '👤' },
  { id: 'admin', label: 'Управление', icon: '⚙️', roles: ADMIN_ROLES },
]

export function BottomNav({ user }: { user: User | null }) {
  const { activeTab, setActiveTab } = useAppStore()
  const { haptic } = useTelegram()

  const visibleItems = NAV_ITEMS.filter(item =>
    !item.roles || (user && item.roles.includes(user.role))
  )

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bottom-nav">
      <div className="glass border-t border-white/5 px-2 pt-2 pb-2">
        <div className="flex items-center justify-around">
          {visibleItems.map((item) => {
            const isActive = activeTab === item.id
            return (
              <button
                key={item.id}
                onClick={() => {
                  haptic.select()
                  setActiveTab(item.id as any)
                }}
                className={`
                  flex flex-col items-center gap-1 px-3 py-2 rounded-2xl
                  transition-all duration-200 touch-feedback min-w-[48px]
                  ${isActive
                    ? 'bg-accent-green/10 text-accent-green'
                    : 'text-text-muted'
                  }
                `}
              >
                <span className={`text-xl leading-none ${isActive ? 'scale-110' : ''} transition-transform`}>
                  {item.icon}
                </span>
                <span className={`text-[10px] font-semibold tracking-wide ${isActive ? 'text-accent-green' : 'text-text-muted'}`}>
                  {item.label}
                </span>
              </button>
            )
          })}
        </div>
      </div>
    </nav>
  )
}
