// src/app/page.tsx
'use client'

import { useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useTelegram } from '@/hooks/useTelegram'
import { useAppStore } from '@/store'
import { profileApi, setInitData } from '@/services/api'
import { BottomNav } from '@/components/layout/BottomNav'
import { Dashboard } from '@/components/features/Dashboard'
import { Search } from '@/components/features/Search'
import { Checklist } from '@/components/features/Checklist'
import { Plan } from '@/components/features/Plan'
import { Profile } from '@/components/features/Profile'
import { Admin } from '@/components/features/Admin'

function LoadingScreen() {
  return (
    <div className="fixed inset-0 bg-bg flex flex-col items-center justify-center gap-4">
      <div className="relative">
        <div className="w-16 h-16 rounded-2xl bg-accent-green/20 flex items-center justify-center">
          <span className="text-3xl">🍳</span>
        </div>
        <div className="absolute -inset-1 rounded-2xl border-2 border-accent-green/30 animate-ping" />
      </div>
      <div className="text-center">
        <p className="font-display text-lg font-bold text-text-primary">ОКО Кухня</p>
        <p className="text-text-muted text-sm mt-1">Загрузка...</p>
      </div>
    </div>
  )
}

function ErrorScreen({ message }: { message: string }) {
  return (
    <div className="fixed inset-0 bg-bg flex flex-col items-center justify-center gap-4 px-6 text-center">
      <span className="text-5xl">⚠️</span>
      <div>
        <p className="font-display text-lg font-bold text-text-primary mb-2">Ошибка входа</p>
        <p className="text-text-muted text-sm leading-relaxed">{message}</p>
        <p className="text-text-muted text-xs mt-3">Войдите через бота @kuxnyaokobot</p>
      </div>
    </div>
  )
}

function AppContent() {
  const { activeTab, user } = useAppStore()

  const screens: Record<string, React.ReactNode> = {
    dashboard: <Dashboard />,
    search: <Search />,
    checklist: <Checklist />,
    plan: <Plan />,
    profile: <Profile />,
    admin: <Admin />,
  }

  return (
    <div className="fixed inset-0 bg-bg flex flex-col">
      <main className="flex-1 overflow-hidden relative">
        {screens[activeTab] || <Dashboard />}
      </main>
      <BottomNav user={user} />
    </div>
  )
}

export default function Home() {
  const { tg, initData } = useTelegram()
  const { setUser, setInitData: storeSetInitData } = useAppStore()

  // Set initData for API
  useEffect(() => {
    if (initData) {
      setInitData(initData)
      storeSetInitData(initData)
    }
  }, [initData])

  const { data: profile, isLoading, error } = useQuery({
    queryKey: ['profile'],
    queryFn: profileApi.get,
    enabled: !!initData || process.env.NODE_ENV === 'development',
    retry: 1,
  })

  useEffect(() => {
    if (profile) setUser(profile)
  }, [profile])

  // Dev mode — mock user
  const isDev = process.env.NODE_ENV === 'development' && !initData

  if (isDev) {
    return (
      <div className="fixed inset-0 bg-bg flex flex-col items-center justify-center gap-4 px-6 text-center">
        <span className="text-5xl">🛠️</span>
        <p className="font-display text-lg font-bold text-text-primary">Dev Mode</p>
        <p className="text-text-muted text-sm">Откройте через Telegram Mini App</p>
      </div>
    )
  }

  if (isLoading) return <LoadingScreen />

  if (error) {
    return <ErrorScreen message="Не удалось загрузить профиль. Убедитесь что вы авторизованы в боте." />
  }

  if (!profile) {
    return <ErrorScreen message="Пользователь не найден. Войдите через бота и введите логин/пароль." />
  }

  return <AppContent />
}
