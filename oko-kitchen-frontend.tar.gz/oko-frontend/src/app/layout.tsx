// src/app/layout.tsx
import type { Metadata } from 'next'
import '@/styles/globals.css'
import { Providers } from '@/components/layout/Providers'

export const metadata: Metadata = {
  title: 'ОКО Кухня',
  description: 'Система управления кухней ОКО Гастробар',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" className="dark">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover" />
        <script src="https://telegram.org/js/telegram-web-app.js" />
      </head>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
