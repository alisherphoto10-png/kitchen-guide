// src/store/index.ts
import { create } from 'zustand'
import type { User } from '@/types'

type Tab = 'dashboard' | 'search' | 'checklist' | 'plan' | 'profile' | 'admin'

interface AppState {
  user: User | null
  setUser: (user: User | null) => void

  activeTab: Tab
  setActiveTab: (tab: Tab) => void

  initData: string
  setInitData: (data: string) => void

  isLoading: boolean
  setLoading: (loading: boolean) => void
}

export const useAppStore = create<AppState>((set) => ({
  user: null,
  setUser: (user) => set({ user }),

  activeTab: 'dashboard',
  setActiveTab: (tab) => set({ activeTab: tab }),

  initData: '',
  setInitData: (data) => set({ initData: data }),

  isLoading: true,
  setLoading: (loading) => set({ isLoading: loading }),
}))
