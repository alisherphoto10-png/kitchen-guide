#!/bin/bash
# deploy.sh — запустить на сервере для деплоя frontend

set -e

echo "🚀 Деплой ОКО Кухня Frontend..."

# Папка для frontend
FRONTEND_DIR="/home/oko-kitchen/oko-kitchen/frontend"
mkdir -p $FRONTEND_DIR

# Перейти в папку
cd $FRONTEND_DIR

# Установить зависимости
echo "📦 Установка зависимостей..."
npm install

# Собрать проект
echo "🔨 Сборка..."
NEXT_PUBLIC_API_URL=https://kitchen2026.chefplan.ru npm run build

# Скопировать out/ в папку которую отдаёт Nginx
echo "📁 Копирование файлов..."
cp -r out/* /home/oko-kitchen/frontend/ 2>/dev/null || true
# Или если out/ и есть папка Nginx:
# mv out /home/oko-kitchen/frontend

echo "✅ Готово! Frontend задеплоен."
echo "🌐 Откройте: https://kitchen2026.chefplan.ru"
