# ОКО Кухня — Frontend

Telegram Mini App для управления кухней ресторана ОКО Гастробар.

## Стек

- Next.js 15 (Static Export)
- React 19
- TypeScript
- TailwindCSS
- TanStack Query
- Zustand
- Telegram WebApp SDK

## Запуск локально

```bash
npm install
npm run dev
```

## Деплой на сервер

```bash
# 1. Загрузить файлы на сервер
scp -r . root@103.74.94.58:/home/oko-kitchen/oko-kitchen/frontend

# 2. На сервере
cd /home/oko-kitchen/oko-kitchen/frontend
npm install
NEXT_PUBLIC_API_URL=https://kitchen2026.chefplan.ru npm run build

# 3. Скопировать собранные файлы в папку Nginx
cp -r out/* /home/oko-kitchen/frontend/
```

## Структура

```
src/
├── app/           — Next.js страницы
├── components/
│   ├── layout/    — BottomNav, Providers
│   └── features/  — Dashboard, Search, Checklist, Plan, Profile, Admin
├── hooks/         — useTelegram
├── services/      — API клиент
├── store/         — Zustand store
└── types/         — TypeScript типы
```

## API

Backend: `https://kitchen2026.chefplan.ru`

Авторизация: `Authorization: tg <initData>`
